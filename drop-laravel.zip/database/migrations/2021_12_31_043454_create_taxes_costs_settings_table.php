<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTaxesCostsSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('taxes_costs_settings', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('territory_id')->unsigned();
            $table->integer('location_id')->unsigned()->nullable();
            $table->double('minimum_order_cost', 10, 2)->default(0.00);
            $table->double('delivery_fee', 8, 2)->default(0.00);
            $table->double('cost_for_free_delivery', 10, 2)->default(0.00);
            $table->double('state_tax', 5, 2)->default(0.00);
            $table->double('local_tax', 5, 2)->default(0.00);
            $table->double('excise_tax', 5, 2)->default(0.00);
            $table->double('cannabis_tax_medical', 5, 2)->default(0.00);
            $table->double('cannabis_tax_adult', 5, 2)->default(0.00);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('taxes_costs_settings');
    }
}
