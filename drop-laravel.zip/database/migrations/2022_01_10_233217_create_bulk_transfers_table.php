<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBulkTransfersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bulk_transfers', function (Blueprint $table) {
            $table->id();
            $table->integer('from_inventory_id');
            $table->integer('to_inventory_id');
            $table->integer('dispensary_id')->unsigned();
            $table->json('products')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('dispensary_id')->references('id')->on('dispensaries')->onUpdate('cascade')->onDelete('cascade');
        });

        Schema::create('bulk_templates', function (Blueprint $table) {
            $table->id();
            $table->integer('dispensary_id')->unsigned();
            $table->string('name', 255);
            $table->integer('from_inventory_id');
            $table->integer('to_inventory_id');
            $table->json('products')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('dispensary_id')->references('id')->on('dispensaries')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bulk_transfers');
        Schema::dropIfExists('bulk_templates');
    }
}
