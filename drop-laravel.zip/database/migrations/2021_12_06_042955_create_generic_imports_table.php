<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGenericImportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('generic_imports', function (Blueprint $table) {
            $table->id();
            $table->json('data');
            $table->integer('new_items')->nullable();
            $table->integer('existing_items')->nullable();
            $table->decimal('total_price', 12, 2)->nullable();
            $table->string('import_type');
            $table->integer('dispensary_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->enum('user_type', ['admin', 'dispensary_user']);
            $table->enum('status', ['COMPLETED', 'PENDING'])->default('PENDING');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('generic_imports');
    }
}
