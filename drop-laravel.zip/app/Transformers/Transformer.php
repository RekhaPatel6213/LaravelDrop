<?php

namespace App\Transformers;

use Illuminate\Support\Carbon;
use League\Fractal\TransformerAbstract;
use League\Fractal\Resource\Item;

class Transformer extends TransformerAbstract
{
    public function addTimestamp($modelObj)
    {
        return [
            'created_at' => $this->toSupportedDateTime($modelObj->created_at),
            'updated_at' => $this->toSupportedDateTime($modelObj->updated_at)
        ];
    }

    public function addTimestampWithDelete($modelObj)
    {
        return $this->addTimestamp($modelObj)+ [
            'deleted_at' => $this->toSupportedDateTime($modelObj->deleted_at),
        ];
    }

    public function toSupportedDateTime(Carbon $date = null)
    {
        if ($date !== null) {
            return [
                'date'     => (string) $date->format('Y-m-d H:i:s'),
                'timezone' => (string) $date->getTimezone()
            ];
        }

        return null;
    }
    
    protected function item($data, $transformer, $resourceKey = null): Item
    {
        if ($data === null) {
            return $this->null();
        }
        return parent::item($data, $transformer, $resourceKey);
    }
}
