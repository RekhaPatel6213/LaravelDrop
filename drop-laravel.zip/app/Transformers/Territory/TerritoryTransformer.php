<?php

namespace App\Transformers\Territory;

use App\Transformers\Transformer;
use App\Models\Territory\Territory;
use Illuminate\Support\Facades\Route;
use App\Transformers\Hub\InventoryTransformer;
use App\Models\Territory\TerritoryModule;
//use App\Transformers\Territory\TerritoryModuleTransformer
use App\Transformers\Driver\DriverTransformer;
use App\Transformers\LocationTransformer;
use App\Transformers\Hub\DispensaryUserTransformer;

class TerritoryTransformer extends Transformer
{
    /**
     * List of resources to automatically include.
     *
     * @var array
     */
    protected array $defaultIncludes = [
        'locations',
        'drivers',
        'dispensary_users',
        'invenotries'
    ];

    public function transform(Territory $territory)
    {
        $data = [];
        if($territory->type === Territory::GEO){
            $data['geo_points'] = $territory->geoPoints;
            $data['minimum_order_cost'] = $territory->taxesCosts ? $territory->taxesCosts->minimum_order_cost : null;
            $data['delivery_fee'] = $territory->taxesCosts ? $territory->taxesCosts->delivery_fee : null;
            $data['cost_for_free_delivery'] = $territory->taxesCosts ? $territory->taxesCosts->cost_for_free_delivery : null;
        }

        return [
            'id' => $territory->id,
            'name' => $territory->name,
            'type' => $territory->type,
        ] + $data;
    }

    public function includeInvenotries(Territory $territory)
    {
        if (Route::currentRouteName() === 'territory.view' && $territory->inventoryModules) {
            return $this->Collection($territory->inventoryModules, new InventoryTransformer());
        }
        return null;
    }

    public function includeDrivers (Territory $territory)
    {
        $drivers = $this->getModuleTypeData($territory->territoryModule, TerritoryModule::DRIVER);
        if (Route::currentRouteName() === 'territory.view' && $drivers) {
            return $this->Collection($drivers, new DriverTransformer());
        }
        return null;
    }

    public function includeLocations(Territory $territory)
    {
        $locations = $this->getModuleTypeData($territory->territoryModule, TerritoryModule::LOCATION);
        if (Route::currentRouteName() === 'territory.view' && $locations) {
            return $this->Collection($locations, new LocationTransformer());
        }
        return null;
    }

    public function includeDispensaryUsers(Territory $territory)
    {
        $users = $this->getModuleTypeData($territory->territoryModule, TerritoryModule::DISPENSARYUSER);
        if (Route::currentRouteName() === 'territory.view' && $users) {
            return $this->Collection($users, new DispensaryUserTransformer());
        }
        return null;
    }

    public function getModuleTypeData($territoryModule, string $type)
    {
        $newModules = [];
        if ($territoryModule) {
            $modules = $territoryModule->where('module_type',$type);
            foreach($modules as $module){
                $newModules[] = $module->module;
            }
        }
        return $newModules;
    }
}
