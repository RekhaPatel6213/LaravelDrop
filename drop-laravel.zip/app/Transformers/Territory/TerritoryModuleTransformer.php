<?php

namespace App\Transformers\Territory;

use League\Fractal\TransformerAbstract;
use App\Models\Territory\TerritoryModule;

class TerritoryModuleTransformer extends TransformerAbstract
{

    public function transform(TerritoryModule $module)
    {
        return [
            ''
        ];
    }
}
