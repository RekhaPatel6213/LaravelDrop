<?php

namespace App\Transformers\Territory;

use League\Fractal\TransformerAbstract;
use App\Models\Territory\Territory;
use App\Models\Territory\TerritoryModule;
use App\Transformers\Driver\DriverTransformer;
use App\Transformers\Territory\TerritoryTransformer;

class TerritoryListTransformer extends TransformerAbstract
{
    protected array $defaultIncludes = [
        'drivers'
    ];

    public function transform(Territory $territory)
    {
        $locations = $territory->territoryModule->where('module_type',TerritoryModule::LOCATION);
        return [
            'id' => $territory->id,
            'name' => $territory->name,
            'type' => $territory->type,
            'invenotries' => $territory->inventoryModules ? $territory->inventoryModules->pluck('name') : [],
            'zip_codes' => data_get($locations, '*.module.zip_code'),
        ];
    }

    public function includeDrivers (Territory $territory)
    {
        $drivers = TerritoryTransformer::getModuleTypeData($territory->territoryModule, TerritoryModule::DRIVER);
        if ($drivers) {
            return $this->Collection($drivers, new DriverTransformer());
        }
        return null;
    }
}
