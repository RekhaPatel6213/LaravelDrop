<?php

namespace App\Transformers;

use App\Models\GenericImport;
use App\Transformers\Transformer;
use Illuminate\Support\Facades\Route;

class GenericImportTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(GenericImport $import)
    {
        $data = [];
        if (Route::currentRouteName() !== 'product.import.history') {
            $data['data'] = $import->data;
        }

        if (in_array(Route::currentRouteName(), ['product.import'])) {
            $key = 0;
            $products = [];
            foreach ($import->data as $priority) {
                foreach ($priority as $parentCategory) {
                    foreach ($parentCategory as $product) {
                        $products[$key] = $product;
                        $key++;
                    }
                }
            }
            $data['data'] = $products;
        }

        return [
            "id" => $import->id,
            'new_items' => $import->new_items,
            'existing_items' => $import->existing_items,
            'total_price' => $import->total_price,
            'user' => $import->user->full_name
        ] + $data + $this->addTimestamp($import);
    }
}
