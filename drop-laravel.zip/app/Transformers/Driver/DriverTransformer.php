<?php

namespace App\Transformers\Driver;

use League\Fractal\TransformerAbstract;
use Illuminate\Support\Facades\Route;

class DriverTransformer extends TransformerAbstract
{
    public function transform($driver)
    {
        $field = [];
        if ( in_array(Route::currentRouteName(),array('drivers.save','drivers.update','drivers.patch')) ) {
            $field['email'] = $driver->email;
            $field['vehicle_type'] = $driver->vehicle_type;
            $field['vehicle_model'] = $driver->vehicle_model;
            $field['vehicle_color'] = $driver->vehicle_color;
            $field['vehicle_licence'] = $driver->vehicle_licence;
        }

        if (in_array(Route::currentRouteName(),array('drivers.list','drivers.get'))) {
            $field['status'] = $driver->status;
            $field['device_type'] = $driver->device_type;
            $field['device_version'] = $driver->device_version;
        }

        return [
            'id' => $driver->id,
            'profile_image' => $driver->hasMedia('profile_images') ? $driver->getFirstMediaUrl('profile_images') : '',
            'name' => $driver->fullName,
            'phone' => $driver->phone,
            'territory_names' => $driver->territory_names,

        ] + $field;

    }
}
