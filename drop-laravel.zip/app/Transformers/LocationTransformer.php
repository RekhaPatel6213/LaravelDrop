<?php

namespace App\Transformers;

use League\Fractal\TransformerAbstract;
use App\Models\Location\Location;

class LocationTransformer extends TransformerAbstract
{
    public function transform(Location $location)
    {
        return [
            'zip_code' =>$location->zip_code,
            'city' =>$location->city,
            'state' =>$location->state,
            'short_state' =>$location->short_state,
            'country' =>$location->country,
            'country_code' =>$location->country_code
        ];
    }
}
