<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\CreditCard;

class CreditCardTransformer extends TransformerAbstract
{
    public function transform(CreditCard $creditCard)
    {
        return [
            'id' => $creditCard->id,
            'card_number' => $creditCard->card_number,
            'brand' => $creditCard->brand,
            'exp_month' => $creditCard->exp_month,
            'exp_year' => $creditCard->exp_year,
            'is_default' => $creditCard->is_default
        ];
    }
}
