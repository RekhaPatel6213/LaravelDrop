<?php

namespace App\Transformers\Hub;

use App\Models\Brand\Brand;
use App\Transformers\Transformer;


class BrandTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Brand $brand)
    {
        return [
            'id' => $brand->id,
            'name' => $brand->name,
        ];
    }
}
