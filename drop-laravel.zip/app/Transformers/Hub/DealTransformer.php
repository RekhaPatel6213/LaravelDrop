<?php

namespace App\Transformers\Hub;

use App\Models\Hub\Deal;
use App\Transformers\Transformer;
use Illuminate\Support\Facades\Route;

class DealTransformer extends Transformer
{
    protected $fields = [];

    public function __construct()
    {
        $detailRoutes = ['deals.list'];
        //if (!in_array(request()->route()->getName(), $detailRoutes)) {
        if (!in_array(Route::currentRouteName(), $detailRoutes)) {
            $this->fields = [
                'slug',
                'sku',
                'description',
                'deal_type',
                'discount_type',
                'applied_on',
                'condition_on',
                'discount_value',
                'total_usage_limit',
                'per_user_limit',
                'min_spend',
                'max_spend',
                'active_days',
                'start_time',
                'end_time',
                'start_date',
                'end_date',
                'number_of_x',
                'added_by',
                'status',
            ];
        }
    }
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Deal $deal)
    {
        $transformed = [
            'id' => $deal->id,
            'name' => $deal->name,
            'deal_type' => $deal->deal_type,
            'discount_type' => $deal->deal_type != Deal::NORMAL ? $deal->applied_on . " - " . $deal->discount_type : $deal->discount_type,
            'frequency' => $deal->frequency,
        ];

        if (empty($this->fields)) {
            return $transformed;
        }

        foreach ($this->fields as $field) {
            $transformed[$field] = $deal->$field;
        }

        return $transformed + $this->addTimestamp($deal);
    }
}
