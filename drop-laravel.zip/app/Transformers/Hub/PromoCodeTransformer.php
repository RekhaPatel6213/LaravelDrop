<?php

namespace App\Transformers\Hub;

use App\Models\Hub\PromoCode;
use App\Transformers\Transformer;


class PromoCodeTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(PromoCode $promoCode)
    {
        return [
            'id' => $promoCode->id,
            'promo_code' => $promoCode->promo_code,
            'promo_overview' => $promoCode->promo_overview,
            'applicable_to' => $promoCode->applicable_to,
            'discount_type' => $promoCode->discount_type,
            'discount_value' => $promoCode->discount_value,
            'product_id' => $promoCode->product_id,
            'applies_to' => $promoCode->applies_to,
            'use_minimum' => $promoCode->use_minimum,
            'minimum_amount' => $promoCode->minimum_amount,
            'unlimited' => $promoCode->unlimited,
            'usage_limit' => $promoCode->usage_limit,
            'start_date_time' => $promoCode->start_date_time,
            'end_date_time' => $promoCode->end_date_time,
            'status' => $promoCode->status,
            'used_count' => $promoCode->used_count,
            'added_by' => $promoCode->added_by,
        ] + $this->addTimestamp($promoCode);
    }
}
