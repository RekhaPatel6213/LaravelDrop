<?php

namespace App\Transformers\Hub\Product;

use App\Transformers\Transformer;
use App\Models\Hub\BulkTransfer;
use App\Models\Activity;
use App\Http\Traits\ProductInventoryTrait;

class BulkTransferTransformer extends Transformer
{
    use ProductInventoryTrait;

    public function transform(BulkTransfer $bulkTransfer)
    {
        return [
            'id' => $bulkTransfer->id,
            'dispensary_id' => $bulkTransfer->dispensary_id,
            'fromInventory' => ['id' => $bulkTransfer->from_inventory_id, 'name' => $bulkTransfer->fromInventory->name ?? Activity::UNALLOCATED],
            'toInventory' => ['id' => $bulkTransfer->to_inventory_id, 'name' => $bulkTransfer->toInventory->name ?? Activity::UNALLOCATED],
            'products' => $this->getBulkProductLogDetails($bulkTransfer->id)
        ] + $this->addTimestamp($bulkTransfer);
    }
}
