<?php

namespace App\Transformers\Hub\Product;

use App\Models\Hub\Product;
use App\Transformers\Hub\CategoryTransformer;
use App\Transformers\Transformer;

/**
 * @OA\Schema(
 *     schema="ProductInclude",
 *     type="array",
 *     @OA\Items(type="string", enum={"product_details","taxons"})
 * )
 */
class ProductTransformer extends Transformer
{
    /**
     * List of resources to automatically include.
     *
     * @var array
     */
    protected $includes = [
        'taxons',
        'product_details',
    ];

    protected array $defaultIncludes = [];

    public function __construct()
    {
        $this->defaultIncludes = $this->includes;

        if (request()->has('includes')) {
            $this->defaultIncludes = request()->includes !== null ? explode(',', request()->includes) : [];
        }
    }

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Product $product)
    {
        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'sku' => $product->sku,
            'description' => $product->description,
            'brand' => $product->brand,
            'state' => $product->state->value(),
            'thc' => $product->thc,
            'thc_type' => $product->thc_type,
            'cbd' => $product->cbd,
            'cbd_type' => $product->cbd_type,
            'cbn' => $product->cbn,
            'cbn_type' => $product->cbn_type,
            'is_featured' => $product->is_featured,
            'strain_type' => $product->strain_type,
            'product_type' => $product->product_type,
            'quantity_type' => $product->quantity_type,
            'is_unlimited' => $product->is_unlimited,
            'logo' => $product->hasMedia('logo') ? $product->getFirstMedia(Product::MEDIATYPE)->getFullUrl('thumb') : null,
            'priority' => $product->priority,
        ] + $this->addTimestampWithDelete($product);
    }

    public function includeTaxons(Product $product)
    {
        if ($product->taxons) {
            return $this->Collection($product->taxons, new CategoryTransformer(false));
        }

        return null;
    }

    public function includeProductDetails(Product $product)
    {
        if ($product->productDetails) {
            return $this->Collection($product->productDetails, new ProductDetailTransformer());
        }

        return null;
    }
}
