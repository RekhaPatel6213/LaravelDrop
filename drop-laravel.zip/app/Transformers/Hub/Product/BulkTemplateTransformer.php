<?php

namespace App\Transformers\Hub\Product;

use App\Transformers\Transformer;
use App\Models\Hub\BulkTemplate;

class BulkTemplateTransformer extends Transformer
{
    public function transform(BulkTemplate $template)
    {
        return [
            'id' => $template->id,
            'name' => $template->name,
            'dispensary_id' => $template->dispensary_id,
            'from_inventory_id' => $template->id,
            'to_inventory_id' => $template->id,
            'products' => $template->products
        ] + $this->addTimestampWithDelete($template);
    }
}
