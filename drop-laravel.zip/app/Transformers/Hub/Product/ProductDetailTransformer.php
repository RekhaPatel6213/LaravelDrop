<?php

namespace App\Transformers\Hub\Product;

use App\Models\Hub\ProductDetail;
use League\Fractal\TransformerAbstract;

class ProductDetailTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(ProductDetail $productDetail)
    {
        return [
            'id' => $productDetail->id,
            'variant_id' => $productDetail->variant_id,
            'wholesale_price' => $productDetail->wholesale_price,
            'price' => $productDetail->price,
            'stock' => $productDetail->stock
        ];
    }
}
