<?php

namespace App\Transformers\Hub\Product;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\Product;
use App\Models\Hub\ProductDetail;
use App\Models\Hub\ProductInventory;
use App\Http\Traits\ProductInventoryTrait;
use Illuminate\Support\Facades\Route;
use App\Settings\DispensaryAccessSettings;
use App\Settings\DispensarySettings;
use App\Http\Traits\ServiceTrait;

class ProductInventoryDetailsTransformer extends TransformerAbstract
{
    use ProductInventoryTrait, ServiceTrait;

    protected $modelId;
    protected $modelType;
    protected $inventoryFeature;
    protected $dropkit;

    public function __construct()
    {
        $this->modelId = request()->route('modelId') ?? null;
        $this->modelType = $this->getProductInventoryModelType();
        $this->inventoryFeature = $this->getInventoryAccess();
        $this->dropkit = $this->getDropkitSetting();
    }

    public function transform(Product $product)
    {
        $quantityType = in_array($product->quantity_type, [Product::PREPACKAGED, Product::UNITS]) ? Product::UNITS : Product::GRAMS;

        if ($product->quantity_type === Product::PREPACKAGED) {
            $allStocDetails = $this->getStockDetails($product);
        }

        if ($product->quantity_type !== Product::PREPACKAGED) {
            $allStocDetails = $this->getSingleStockDetails($product);
        }

        return [
            'id' => $product->id,
            'name' => $product->name,
            'brand' => $product->brand,
            'modelType' => $this->modelType,
            'quantity_type' => $quantityType,
            'stock_details' => $allStocDetails['stocks'] ?? null,
            'allocated_stock' => $allStocDetails['models'] ?? null
        ];
    }

    public function getSingleStockDetails(Product $product)
    {
        $stocks = $models = [];
        $unallocatedStock = $this->getAvailableStock($product, $this->modelType);
        
        if ($this->modelId === null) {
            $stocks[$product->id] = [
                'stock' => $product->stock,
                'allocated_stock' => (int) ($product->stock - $unallocatedStock),
                'unallocated_stock' => $unallocatedStock
            ];
        }

        $models = $this->modelDataFormate($product, $models);
        return ['stocks' => $stocks, 'models' => $models];
    }

    public function getStockDetails(Product $product)
    {
        $stocks = $models = [];
        $details = $product->productDetails;
        $variants = data_get($details, '*.variant.name');

        $models = $this->modelDataFormate($product, $models);

        if ($details) {
            foreach ($details as $detail) {
                $variantName = $detail->variant->name;
                $unallocatedStock = $this->getAvailableStock($product, $this->modelType, $detail->id);
                $stocks[$detail->id] = $this->stockDataFormate($detail->variant_id, $variantName, $detail->stock, $unallocatedStock);
            }  
        }

        $models = $this->modelsWithNoStock($models, $variants);

        if ($this->modelId !== null) {
            $stocks = $variants;
        }
        return ['stocks' => $stocks, 'models' => $models];
    }

    public function stockDataFormate(int $variantId, string $variantName, int $stock, int $unallocatedStock): array
    {
        return [
            'varient_id' => $variantId,
            'variant' => $variantName,
            'stock' => $stock,
            'allocated_stock' => (int) ($stock - $unallocatedStock),
            'unallocated_stock' => $unallocatedStock
        ];
    }

    public function modelDataFormate($detail, array $models)
    {
        $inventories = $detail->inventories->where('model_type', $this->modelType);

        if($this->inventoryFeature){
           $inventoryModelType = $this->getProductInventoryModelType();
           $inventories = $inventories->where('model_type', $inventoryModelType);
        }

        if ($this->modelId !== null) {
            $inventories = $inventories->where('model_id', $this->modelId);
        }

        if (count($inventories) > 0) {
            foreach ($inventories as $key => $inventory) {
                $variantName = null;
                $pDetail = $detail->productDetails->where('id', $inventory->product_detail_id)->first();
                if($pDetail && $pDetail->variant){
                    $variantName = $pDetail->variant->name;
                }
                
                $modelName = $inventory->model->name;

                if (!array_key_exists($modelName, $models)) {
                    $models[$modelName] = [
                        'model_name' => $modelName,
                        'model_type' => $inventory->model_type,
                        'model_id' => $inventory->model_id,
                    ];
                }

                array_push($models[$modelName], ['variant' => $variantName, 'stock' => $inventory->stock]);
            }
        }
        return $models;
    }

    public function modelsWithNoStock(array $models, array $variants)
    {
        if ($variants && $models) {
            $models = array_map(function($model) use ($variants){
                $usedVariants = data_get($model, '*.variant');
                $leftVariants = array_diff($variants, $usedVariants);
                
                foreach ($leftVariants as $variant) {
                    $model = array_merge($model, [['variant' => $variant, 'stock' => 0]]);
                }
                return $model;
            }, $models);
        }
        return $models;
    }
}
