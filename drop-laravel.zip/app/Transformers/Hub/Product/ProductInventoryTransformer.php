<?php

namespace App\Transformers\Hub\Product;

use App\Transformers\Transformer;
use App\Models\Activity;

class ProductInventoryTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Activity $activity)
    {
        return [
            'product_id' => $activity->getExtraProperty('product_id'),
            'product_name' => $activity->getExtraProperty('product_name') ?? $activity->subject->name,
            'variant' => $activity->getExtraProperty('variant'),
            'type' => $activity->getExtraProperty('action'),
            'stock' => $activity->getExtraProperty('stock'),
            'product_stock' => $activity->getExtraProperty('product_stock'),
            'model_name' => $activity->getExtraProperty('model_name') ?? Activity::UNALLOCATED,
            'added_by' => $activity->getExtraProperty('added_by') ?? $activity->causer->full_name,
        ] + $this->addTimestamp($activity);
    }
}
