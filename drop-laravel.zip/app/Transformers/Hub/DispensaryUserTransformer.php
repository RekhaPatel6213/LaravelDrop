<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Admin\Dispensary\DispensaryUser;
use Illuminate\Support\Facades\Route;

class DispensaryUserTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(DispensaryUser $dispensaryUser)
    {
        $field = [];
        if (Route::currentRouteName() === 'dispensary.user.input') {
            $field['first_name'] = $dispensaryUser->first_name;
            $field['last_name'] = $dispensaryUser->last_name;
            $field['phone'] = $dispensaryUser->phone;
            $field['staff_role'] = $dispensaryUser->staff_role;
            $field['territory_ids'] = $dispensaryUser->territory_ids;
            $field['permissions'] = $dispensaryUser->getDirectPermissions()->pluck('id');
        }
        if (Route::currentRouteName() === 'dispensary.user.list' || Route::currentRouteName() === 'dispensary.user.status') {
            $field['full_name'] = $dispensaryUser->full_name;
            $field['last_activity'] = $dispensaryUser->last_activity;
            $field['status'] = $dispensaryUser->status;
            $field['is_owner'] = $dispensaryUser->is_owner;
        }
        return [
            'id' => (int) $dispensaryUser->id,
            'email' => $dispensaryUser->email,
            'role' => $dispensaryUser->role,

        ] + $field;
    }
}
