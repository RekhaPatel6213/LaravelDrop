<?php

namespace App\Transformers\Hub;

use App\Models\Hub\Audit;
use App\Transformers\Transformer;
use Illuminate\Support\Facades\Route;

class AuditTransformer extends Transformer
{
    /**
     * Transform the Audit entity.
     *
     * @param \App\Models\Hub\Audit $model
     *
     * @return array
     */
    public function transform(Audit $audit)
    {
        $data = [];
        if (Route::currentRouteName() !== 'audit.list') {
            $data['products'] = $audit->products;
        }

        return [
            'id' => (int) $audit->id,
            'model_name' => $audit->model->name,
            'model_type' => $audit->model_type,
            'model_id' => (int) $audit->model_id,
            'created_by' => $audit->created_by,
        ] + $data + $this->addTimestamp($audit);
    }
}
