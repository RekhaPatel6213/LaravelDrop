<?php

namespace App\Transformers\Hub;

use App\Transformers\Transformer;
use App\Models\Hub\Reward;

class RewardTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Reward $reward)
    {
        return [
            'id' => (int) $reward->id,
            'name' => $reward->name,
            'slug' => $reward->slug,
            'sku' => $reward->sku,
            'points' => $reward->points,
            'is_inventory' => $reward->is_inventory,
            'discount_type' => $reward->discount_type,
            'discount_price' => number_format($reward->discount_price, 2),
            'product_id' => $reward->product_id,
            'product_detail_id' => $reward->product_detail_id,
            'description' => $reward->description,
            'is_birthday' => $reward->is_birthday,
            'logo' => $reward->hasMedia('logo') ? $reward->getFirstMedia('logo')->getUrl('thumb') : NULL
        ];
    }
}
