<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\Banner;
use Illuminate\Support\Facades\Route;

class BannerTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Banner $banner)
    {
        $field = [];
        if (Route::currentRouteName() === 'banner.input') {
            $field['description'] = $banner->description;
            $field['redirect_detail'] = $banner->redirect_detail;
            $field['frequency'] = $banner->frequency;
            $field['days'] = $banner->days;
            $field['from_time'] = $banner->from_time;
            $field['to_time'] = $banner->to_time;
        }
        if (Route::currentRouteName() === 'banner.list' || Route::currentRouteName() === 'banner.status') {
            $field['status'] = $banner->status;
        }
        return [
                'id' => (int) $banner->id,
                'banner_image' => $banner->hasMedia('banner_image') ? $banner->getFirstMedia('banner_image')->getUrl('thumb') : NULL,
                'title' => $banner->title,
                'description' => $banner->description,
                'redirect_type' => $banner->redirect_type,
                'start_date' => $banner->start_date,
                'end_date' => $banner->end_date,
            ] + $field;
    }
}
