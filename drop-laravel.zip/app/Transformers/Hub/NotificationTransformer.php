<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\Notification;

class NotificationTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Notification $notification)
    {
        return [
            'id' => (int) $notification->id,
            'title' => $notification->title,
            'message' => $notification->message,
            'added_by' => $notification->added_by
        ];
    }
}
