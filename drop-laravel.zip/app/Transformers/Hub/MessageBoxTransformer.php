<?php

namespace App\Transformers\Hub;

use App\Models\Hub\MessageBox;
use League\Fractal\TransformerAbstract;

class MessageBoxTransformer extends TransformerAbstract
{
    public function transform(MessageBox $messageBox)
    {
        return [
            'id' => $messageBox->id,
            'dispensary_id' => $messageBox->dispensary_id,
            'title' => $messageBox->title,
            'description' => $messageBox->description,
            'position' => $messageBox->position,
            'added_by' => $messageBox->added_by
        ];
    }
}
