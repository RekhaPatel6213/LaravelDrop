<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\ModelInventory;

class ModelInventoryTransformer extends TransformerAbstract
{
    public function transform(ModelInventory $modelInventory)
    {
        return [
            'model_id' => $modelInventory->model_id,
            'model_name' => $modelInventory->model->name,
        ];
    }
}
