<?php

namespace App\Transformers\Hub;

use App\Transformers\Transformer;
use App\Models\Hub\Inventory;
use App\Transformers\Hub\ModelInventoryTransformer;
use App\Http\Traits\ServiceTrait;
use Illuminate\Support\Facades\Route;

class InventoryTransformer extends Transformer
{
    use ServiceTrait;

    protected array $defaultIncludes = [
        'models'
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Inventory $inventory)
    {
        return [
            'id' => (int) $inventory->id,
            'name' => $inventory->name,
            'is_sale' => $inventory->is_sale,
            'model_type' => $this->getInventoryModelType(),
            'models' => implode(', ',data_get($inventory->modelInventory,'*.model.name')),
        ] + $this->addTimestamp($inventory);
    }

    public function includeModels(Inventory $inventory)
    {
        if (!in_array(Route::currentRouteName(), ['inventory.list', 'territory.view'])) {
            return $this->Collection($inventory->modelInventory, new ModelInventoryTransformer(false));
        }
        return null;
    }
}
