<?php

namespace App\Transformers\Hub;

use App\Models\Hub\Category;
use App\Models\Hub\DispensaryCategory;
use League\Fractal\TransformerAbstract;

class CategoryTransformer extends TransformerAbstract
{
    protected $detailInclude;

    public function __construct($detailInclude = true)
    {
        $this->detailInclude = $detailInclude;
    }

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Category $category)
    {
        $categoryData = $this->formateCategoryData($category);
        if ($this->detailInclude && $category->parent_id === null) {
            $categoryData = array_merge($categoryData, ['children' => $this->categoryDetails($category->children)]);
        }

        return $categoryData;
    }

    private function formateCategoryData($category)
    {
        $categoryData = [
            'id' => $category->id,
            'taxonomy_id' => $category->taxonomy_id,
            'name' => $category->name,
            'slug' => $category->slug,
            'priority' => $category->priority,
            'attribute' => $category->attribute,
            'state' => $category->state,
        ];

        if ($this->detailInclude) {
            $categoryData = array_merge(
                $categoryData,
                [
                    'dispensary_category' => $this->dispensaryCategoryDetails($category->dispensaryCategory),
                    'taxonomy' => $this->taxonomyDetails($category->taxonomy),
                ]
            );
        }

        return $categoryData;
    }

    private function categoryDetails($categories)
    {
        return $categories->map(function ($category) {
            return $this->formateCategoryData($category);
        });
    }

    private function dispensaryCategoryDetails($category)
    {
        if ($category) {
            return [
                'id' => $category->id,
                'description' => $category->description,
                'priority' => $category->priority,
                'icon' => $category->hasMedia(DispensaryCategory::ICON) ? $category->getFirstMedia(DispensaryCategory::ICON)->getUrl('thumb') : null,
                'banner' => $category->hasMedia(DispensaryCategory::BANNER) ? $category->getFirstMedia(DispensaryCategory::BANNER)->getUrl('thumb') : null,
            ];
        }

        return null;
    }

    private function taxonomyDetails($taxonomy)
    {
        if ($taxonomy) {
            return [
                'id' => $taxonomy->id,
                'name' => $taxonomy->name,
                'slug' => $taxonomy->slug,
            ];
        }

        return null;
    }
}
