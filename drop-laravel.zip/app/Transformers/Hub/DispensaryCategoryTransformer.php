<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\DispensaryCategory;

class DispensaryCategoryTransformer extends TransformerAbstract
{
    public function transform(DispensaryCategory $category)
    {
        return [
            'id' => $category->id,
            'description' => $category->description,
            'priority' => $category->priority,
            'icon' => $category->hasMedia(DispensaryCategory::ICON) ? $category->getFirstMedia(DispensaryCategory::ICON)->getUrl('thumb') : NULL,
            'banner' => $category->hasMedia(DispensaryCategory::BANNER) ? $category->getFirstMedia(DispensaryCategory::BANNER)->getUrl('thumb') : NULL
        ];
    }
}
