<?php

namespace App\Transformers\Hub\Dispensary;

use App\Models\Admin\Dispensary\Dispensary;

use League\Fractal\TransformerAbstract;

class DispensaryTransformer extends TransformerAbstract
{
    public function transform(Dispensary $dispensary)
    {
        return [
            'id' => $dispensary->id,
            'name' => $dispensary->name,
            'email' => $dispensary->email,
            'phone' => $dispensary->phone,
            'address' => $dispensary->address,
            'app_name' => $dispensary->app_name,
            'website' => $dispensary->website,
            'state_licence' => $dispensary->state_licence,
            'timezone' => $dispensary->timezone,
            'own_domain' => $dispensary->own_domain,
            'admin_user_id' => $dispensary->admin_user_id,
            'bitly_link' => $dispensary->bitly_link,
            'setup_fee' => $dispensary->setup_fee,
            'services' => $dispensary->services,
            'product_notes' => $dispensary->product_notes,
            'dispatch_minimum' => $dispensary->dispatch_minimum,
            'few_left_banner' => $dispensary->few_left_banner,
            'billing_prompt' => $dispensary->billing_prompt,
            'service_fee_enabled' => $dispensary->service_fee_enabled,
            'service_fee_amount' => $dispensary->service_fee_amount,
            'subscription_type' => $dispensary->subscription_type,
            'status' => $dispensary->status,
        ];
    }
}
