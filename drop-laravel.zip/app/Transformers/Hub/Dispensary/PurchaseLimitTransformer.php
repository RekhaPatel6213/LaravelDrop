<?php

namespace App\Transformers\Hub\Dispensary;

use App\Models\Admin\Dispensary\PurchaseLimit;
use League\Fractal\TransformerAbstract;

class PurchaseLimitTransformer extends TransformerAbstract
{
    public function transform(PurchaseLimit $purchaseLimit)
    {
        return [
            'id' => $purchaseLimit->id,
            'dispensary_id' => $purchaseLimit->dispensary_id,
            'state' => $purchaseLimit->state,
            'flower_rec_limit' => $purchaseLimit->flower_rec_limit,
            'flower_med_limit' => $purchaseLimit->flower_med_limit,
            'con_rec_limit' => $purchaseLimit->con_rec_limit,
            'con_med_limit' => $purchaseLimit->con_med_limit,
            'plant_rec_limit' => $purchaseLimit->plant_rec_limit,
            'plant_med_limit' => $purchaseLimit->plant_med_limit,
        ];
    }
}
