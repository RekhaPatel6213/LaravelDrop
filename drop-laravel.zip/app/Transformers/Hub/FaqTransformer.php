<?php

namespace App\Transformers\Hub;

use App\Models\Hub\Faq;
use App\Transformers\Transformer;

class FaqTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Faq $faq)
    {
        return [
            'id' =>  (int) $faq->id,
            'dispensary_id' => $faq->dispensary_id,
            'question' => $faq->question,
            'answer' => $faq->answer,
            'priority' => $faq->priority,
            'status' => $faq->status
        ];
    }
}
