<?php

namespace App\Transformers\Hub;

use League\Fractal\TransformerAbstract;
use App\Models\Hub\Vendor;

class VendorTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Vendor $vendor)
    {
        return [
            'id' => (int) $vendor->id,
            'dispensary_id' => $vendor->dispensary_id,
            'name' => $vendor->name,
            'email' => $vendor->email,
            'licence' => $vendor->licence
        ];
    }
}
