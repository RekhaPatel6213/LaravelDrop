<?php

namespace App\Transformers\Hub;

use App\Transformers\Transformer;
use App\Models\Hub\SMSCampaign;
use Illuminate\Support\Facades\Route;

class SMSCampaignTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(SMSCampaign $smscampaign)
    {
        $field = [];
        if (Route::currentRouteName() === 'smscampaign.input') {
            $field['patient_type'] = $smscampaign->patient_type;
            $field['segmentation'] = $smscampaign->segmentation;
            $field['territory_ids'] = $smscampaign->territory_ids;
            $field['type_scheduled'] = $smscampaign->type_scheduled;
            $field['schedule_date'] = ($smscampaign->type_scheduled === SMSCampaign::TYPE_SCHEDULE['SEND_LATER']) ? $smscampaign->schedule_date : NULL ;
            $field['schedule_time'] = ($smscampaign->type_scheduled === SMSCampaign::TYPE_SCHEDULE['SEND_LATER']) ? $smscampaign->schedule_time : [NULL];
            $field['added_by'] = $smscampaign->added_by;
        }
        if (Route::currentRouteName() === 'smscampaign.list') {
            $field['create_at'] = $smscampaign->created_at;
            $field['territory_names'] = $smscampaign->territory_names;
        }
        return [
                'id' => (int) $smscampaign->id,
                'message' => $smscampaign->message,
                'status' => $smscampaign->status,
                'total_customer' => $smscampaign->total_customer,
                'total_send' => $smscampaign->total_send,

            ] + $field;
    }
}
