<?php

namespace App\Transformers\Hub;

use App\Models\Hub\Page;
use App\Transformers\Transformer;

class PageTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Page $page)
    {
        return [
            'id' =>  (int) $page->id,
            'dispensary_id' => $page->dispensary_id,
            'name' => $page->name,
            'page_code' => $page->page_code,
            'group' => $page->group,
            'html_content' => $page->html_content,
            'priority' => $page->priority,
            'sub_id' => $page->sub_id
        ];
    }
}
