<?php

namespace App\Transformers\Admin;

use App\Models\Admin\Faq;
use League\Fractal\TransformerAbstract;

class FaqTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Faq $faq)
    {
        return [
            'id' =>  $faq->id,
            'question' => $faq->question,
            'answer' => $faq->answer,
            'priority' => $faq->priority,
            'status' => $faq->status
        ];
    }
}
