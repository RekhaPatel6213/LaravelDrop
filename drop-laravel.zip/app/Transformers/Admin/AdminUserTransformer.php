<?php

namespace App\Transformers\Admin;

use App\Models\Admin\AdminUser;
use App\Transformers\Transformer;

/**
 * @OA\Schema(
 *     schema="AdminUserInclude",
 *     type="array",
 *     @OA\Items(type="string", enum={"roles"})
 * )
 */
class AdminUserTransformer extends Transformer
{
    protected array $availableIncludes = [
        //'roles'
    ];

    public function transform(AdminUser $admin)
    {
        return [
                'id' => $admin->id,
                'first_name' => $admin->first_name,
                'last_name' => $admin->last_name,
                'full_name' => $admin->full_name,
                'email' => $admin->email,
                'phone_number' => $admin->phone_number,
                'role' => $admin->role,
                'status' => $admin->status,
                'last_login' => $this->toSupportedDateTime($admin->last_login),
            ] + $this->addTimestampWithDelete($admin);
    }
}
