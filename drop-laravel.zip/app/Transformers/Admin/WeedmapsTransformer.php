<?php

namespace App\Transformers\Admin;

use App\Transformers\Transformer;
use App\Models\Admin\Integration;
use App\Settings\WeedmapsSettings;

class WeedmapsTransformer extends Transformer
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(WeedmapsSettings $weedmapsSettings)
    {
        return [
            'wm_client_id' => $weedmapsSettings->wm_client_id,
            'wm_client_secret' => $weedmapsSettings->wm_client_secret,
        ];
    }
}
