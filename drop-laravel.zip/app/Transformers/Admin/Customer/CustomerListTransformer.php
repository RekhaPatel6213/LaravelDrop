<?php

namespace App\Transformers\Admin\Customer;

use App\Models\Admin\Customer\Customer;
use League\Fractal\TransformerAbstract;

class CustomerListTransformer extends TransformerAbstract
{
    public function transform($customer)
    {
        return [
            'id' => $customer->id,
            'name' => $customer->customer_names,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'dispensaries' => $customer->dispensary_names,
        ];
    }
}
