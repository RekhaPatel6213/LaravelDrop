<?php

namespace App\Transformers\Admin\Customer;

use App\Models\Admin\Customer\Customer;
use League\Fractal\TransformerAbstract;

class DispensaryCustomerListTransformer extends TransformerAbstract
{
    public function transform($customer)
    {
        return [
            'id' => $customer->id,
            'name' => $customer->name,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'status' => $customer->verify_status,
        ];
    }
}
