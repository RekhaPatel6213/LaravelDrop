<?php

namespace App\Transformers\Admin\Customer;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

class CustomerImportDetailsTransformer extends TransformerAbstract
{
    public function transform($import)
    {
        return [
            'id' => $import['preview_id'],
            'date' => Carbon::parse($import['import_date'])->format('F d, Y h:i A'),
            'new_count' => count($import['new']),
            'existing_count' => count($import['existing']),
            'new' => $import['new'],
            'existing' => $import['existing'],
        ];
    }
}
