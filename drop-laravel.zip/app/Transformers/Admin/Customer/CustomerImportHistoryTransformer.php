<?php

namespace App\Transformers\Admin\Customer;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

class CustomerImportHistoryTransformer extends TransformerAbstract
{
    public function transform($history)
    {
        return [
            'id' => $history['id'],
            'date' => Carbon::parse($history['import_date'])->format('F d, Y h:i A'),
            'new' => $history['new'],
            'existing' => $history['existing'],
        ];
    }
}
