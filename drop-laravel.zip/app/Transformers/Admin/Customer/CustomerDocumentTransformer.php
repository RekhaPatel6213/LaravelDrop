<?php

namespace App\Transformers\Admin\Customer;

use App\Models\Admin\Customer\Customer;
use App\Models\Admin\Customer\DispensaryCustomer;
use League\Fractal\TransformerAbstract;

class CustomerDocumentTransformer extends TransformerAbstract
{
    public function transform(DispensaryCustomer $dispensaryCustomer)
    {
        $otherMediaUrls = $this->getOtherMediaUrls($dispensaryCustomer);
        return [
            'customer_id' => $dispensaryCustomer->customer_id,
            'dispensary_id' => $dispensaryCustomer->dispensary_id,
            'card' => $dispensaryCustomer->hasMedia('card') ? $dispensaryCustomer->getFirstMediaUrl('card') : '',
            'medical' => $dispensaryCustomer->hasMedia('medical') ? $dispensaryCustomer->getFirstMediaUrl('medical') : '',
            'other' => $otherMediaUrls,
        ];
    }

    public function getOtherMediaUrls($dispensaryCustomer)
    {
        $mediaCollection = $dispensaryCustomer->getMedia('other');
        $all = [];
        foreach ($mediaCollection as $item) {
            $all[] = $item->getUrl();
        }

        return $all;
    }
}
