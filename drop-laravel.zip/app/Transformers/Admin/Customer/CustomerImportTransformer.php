<?php

namespace App\Transformers\Admin\Customer;

use App\Models\Admin\Customer\Customer;
use League\Fractal\TransformerAbstract;

class CustomerImportTransformer extends TransformerAbstract
{
    public function transform($customer)
    {
        return [
            'preview_id' => $customer['preview_id'],
            'existing' => $customer['existing'],
            'new' => $customer['new'],
        ];
    }
}
