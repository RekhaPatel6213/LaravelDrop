<?php

namespace App\Transformers\Admin\Customer;

use App\Models\Admin\Customer\Customer;
use League\Fractal\TransformerAbstract;

class CustomerTransformer extends TransformerAbstract
{
    public function transform($customer)
    {
        return [
            'id' => $customer->id,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'birth_date' => $customer->birth_date,
            'status' => $customer->status,
            'details' => $customer->dispensaryCustomer,
        ];
    }
}
