<?php

namespace App\Transformers\Admin;

use League\Fractal\TransformerAbstract;

class EmailTemplateListTransformer extends TransformerAbstract
{
    public function transform($mailTemplate)
    {
        return [
            'id' => $mailTemplate->id,
            'subject' => $mailTemplate->subject,
            'mailable' => $mailTemplate->mailable,
        ];
    }
}
