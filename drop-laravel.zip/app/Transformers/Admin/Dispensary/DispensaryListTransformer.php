<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\Dispensary;

use League\Fractal\TransformerAbstract;
use App\Transformers\Transformer;

class DispensaryListTransformer extends TransformerAbstract
{
    public function transform(Dispensary $dispensary)
    {
        return [
            'id' => $dispensary->id,
            'logo' => $dispensary->hasMedia('logos') ? $dispensary->getFirstMedia('logos')->getUrl('thumb') : '',
            'name' => $dispensary->name,
            'customers' => $dispensary->totalCustomer,
            'service_fee_enabled' => $dispensary->service_fee_enabled ? 'Enabled' : 'Disabled',
            'service_fee_amount' => $dispensary->service_fee_amount,
        ];
    }
}
