<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\DispensaryCustomFee;
use League\Fractal\TransformerAbstract;

class DispensaryCustomFeeTransformer extends TransformerAbstract
{
    public function transform(DispensaryCustomFee $customFee)
    {
        return [
            'id' => $customFee->id,
            'title' => $customFee->title,
            'description' => $customFee->description,
            'fee_amount' => $customFee->fee_amount
        ];
    }
}
