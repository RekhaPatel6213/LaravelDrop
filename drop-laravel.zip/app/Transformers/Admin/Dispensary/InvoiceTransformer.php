<?php

namespace App\Transformers\Admin\Dispensary;

use League\Fractal\TransformerAbstract;
use App\Models\Admin\Dispensary\Invoice;

class InvoiceTransformer extends TransformerAbstract
{
    public function transform(Invoice $invoice)
    {
        return [
            'id' => $invoice->id,
            'description' => $invoice->description,
            'invoice_date' => $invoice->invoice_date,
            'amount' => $invoice->amount,
            'status' => $invoice->status,
            'invoice_pdf' => $invoice->invoice_pdf
        ];
    }
}
