<?php

namespace App\Transformers\Admin\Dispensary;

use League\Fractal\TransformerAbstract;
use App\Models\Admin\Dispensary\SubscriptionPrice;

class SubscriptionPriceTransformer extends TransformerAbstract
{
    public function transform(SubscriptionPrice $price)
    {
        return [
            'name' => $price->name,
            'stripe_price_id' => $price->stripe_price_id,
            'amount' => (float)$price->amount,
            'interval' => $price->interval,
            'sms' => (int)$price->sms,
            'recurring_type' => $price->recurring_type
        ];
    }
}
