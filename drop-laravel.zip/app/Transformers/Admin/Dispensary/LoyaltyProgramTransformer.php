<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\LoyaltyProgram;
use League\Fractal\TransformerAbstract;
use Illuminate\Support\Facades\Route;

class LoyaltyProgramTransformer extends TransformerAbstract
{
    protected $fields = [];

    public function __construct()
    {
        $detailRoutes = ['loyalty_program.list'];
        //if (!in_array(request()->route()->getName(), $detailRoutes)) {
        if (!in_array(Route::currentRouteName(), $detailRoutes)) {
            $this->fields = [
                'points',
                'is_default',
                'start_time',
                'end_time',
                'status',
                'schedule',
                'active_days',
                'custom_message'
            ];
        }
    }

    public function transform(LoyaltyProgram $program)
    {
        $transformed = [
            'id' => $program->id,
            'name' => $program->name,
            'points_text' => $program->type == LoyaltyProgram::STANDARD_LOYALTY ? $this->getTypeText($program->points) : $program->points,
            'type' => $program->type,
            'status' => $program->status,
        ];

        if (empty($this->fields)) {
            return $transformed;
        }

        foreach ($this->fields as $field) {
            $transformed[$field] = $program->$field;
        }

        return $transformed;
    }

    protected function getTypeText($points)
    {
        return $points . ' Point for every $1 spent';
    }
}
