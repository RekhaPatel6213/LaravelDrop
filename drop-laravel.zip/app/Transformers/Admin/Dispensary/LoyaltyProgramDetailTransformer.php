<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\LoyaltyProgram;
use League\Fractal\TransformerAbstract;

class LoyaltyProgramDetailTransformer extends TransformerAbstract
{
    public function transform(LoyaltyProgram $program)
    {
        return [
            'points' => $program->points,
            'is_default' => $program->is_default,
            'start_time' => $program->start_time,
            'end_time' => $program->end_time,
            'status' => $program->status,
            'schedule' => $program->schedule,
            'active_days' => $program->active_days,
            'custom_message' => $program->custom_message,
        ];
    }
}
