<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\Dispensary;

use League\Fractal\TransformerAbstract;
use App\Transformers\Transformer;

class DispensaryTransformer extends TransformerAbstract
{
    public function transform(Dispensary $dispensary)
    {
        return [
            'id' => $dispensary->id,
            'logo' => $dispensary->hasMedia('logos') ? $dispensary->getFirstMedia('logos')->getUrl('thumb') : '',
            'header_logo' => $dispensary->hasMedia('header_logos') ? $dispensary->getFirstMedia('header_logos')->getUrl('thumb') : '',
            'app_icon' => $dispensary->hasMedia('app_icons') ? $dispensary->getFirstMedia('app_icons')->getUrl('thumb') : '',
            'name' => $dispensary->name,
            'email' => $dispensary->email,
            'phone' => $dispensary->phone,
            'address' => $dispensary->address,
            'domain' => $dispensary->domains->domain ?? '',
            'first_name' => $dispensary->dispensaryUser->first_name ?? '',
            'last_name' => $dispensary->dispensaryUser->last_name ?? '',
            'contact_email' => $dispensary->dispensaryUser->email ?? '',
            'contact_phone' => $dispensary->dispensaryUser->phone ?? '',
            'admin_user_id' => $dispensary->admin_user_id,
            'bitly_link' => $dispensary->bitly_link,
            'setup_fee' => $dispensary->setup_fee,
            'services' => $dispensary->services,
            'billing_prompt' => $dispensary->billing_prompt,
            'service_fee_enabled' => $dispensary->service_fee_enabled,
            'service_fee_amount' => $dispensary->service_fee_amount,
            'own_domain' => $dispensary->own_domain,
            'subscription_type' => $dispensary->subscription_type,
            'stripe_id' => $dispensary->stripe_id,
            'app_name' => $dispensary->app_name,
            'app_color' => $dispensary->app_color,
            'instagram_url' => $dispensary->instagram_url,
            'facebook_url' => $dispensary->facebook_url,
            'twitter_url' => $dispensary->twitter_url,
            'description' => $dispensary->description,
            'label_tags' => $dispensary->label_tags,
        ];
    }
}
