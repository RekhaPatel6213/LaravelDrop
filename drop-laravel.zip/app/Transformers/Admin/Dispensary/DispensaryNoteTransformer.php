<?php

namespace App\Transformers\Admin\Dispensary;

use League\Fractal\TransformerAbstract;
use Spatie\Activitylog\Models\Activity;

class DispensaryNoteTransformer extends TransformerAbstract
{
    public function transform(Activity $activity)
    {
        return [
            'id' => $activity->id,
            'description' => $activity->description,
            'causer_id' => $activity->causer_id,
            'properties' => $activity->properties,
            'created_at' => $activity->created_at,
            'updated_at' => $activity->updated_at,
        ];
    }
}
