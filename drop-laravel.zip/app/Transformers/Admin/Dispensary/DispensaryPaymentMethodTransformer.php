<?php

namespace App\Transformers\Admin\Dispensary;

use App\Models\Admin\Dispensary\DispensaryPaymentMethod;
use League\Fractal\TransformerAbstract;

class DispensaryPaymentMethodTransformer extends TransformerAbstract
{
    public function transform(DispensaryPaymentMethod $method)
    {
        return [
            'id' => $method->id,
            'dispensary_id' => $method->dispensary_id,
            'payment_slug' => $method->payment_slug,
            'payment_title' => $method->payment_title,
            'description' => $method->description,
            'enable_tip' => $method->enable_tip,
            'enable_cash' => $method->enable_cash,
            'status' => $method->status,
        ];
    }
}
