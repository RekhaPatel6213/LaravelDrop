<?php

namespace App\Transformers\Admin;

use App\Helpers\EmailTemplateHelper;
use League\Fractal\TransformerAbstract;

class EmailTemplateTransformer extends TransformerAbstract
{
    public function transform($mailTemplate)
    {
        return [
            'id' => $mailTemplate->id,
            'subject' => EmailTemplateHelper::encodeDecodeTemplateVars($mailTemplate->subject, false),
            'mailable' => $mailTemplate->mailable,
            'html_template' => EmailTemplateHelper::encodeDecodeTemplateVars($mailTemplate->html_template, false),
            'text_template' => EmailTemplateHelper::encodeDecodeTemplateVars($mailTemplate->text_template, false),
        ];
    }
}
