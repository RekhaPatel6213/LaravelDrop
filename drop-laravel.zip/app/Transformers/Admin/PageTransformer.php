<?php

namespace App\Transformers\Admin;

use League\Fractal\TransformerAbstract;
use App\Models\Admin\Page;

class PageTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Page $page)
    {
        return [
                'id' => (int) $page->id,
                'name' => $page->name,
                'page_code' => $page->page_code,
                'group' => $page->group,
                'html_content' => $page->html_content,
                'priority' => $page->priority,
                'sub_id' => $page->sub_id
            ];
    }
}
