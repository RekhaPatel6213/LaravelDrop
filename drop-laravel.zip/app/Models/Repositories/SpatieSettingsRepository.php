<?php

namespace App\Models\Repositories;

use Spatie\LaravelSettings\SettingsRepositories\DatabaseSettingsRepository;
use Illuminate\Database\Eloquent\Builder;

class SpatieSettingsRepository extends DatabaseSettingsRepository
{
    public function getBuilder(): Builder
    {
        $queryBuilder = parent::getBuilder();
        if (tenant('id')) {
            $queryBuilder->where('dispensary_id', tenant('id'));
        }
        return $queryBuilder;
    }
}
